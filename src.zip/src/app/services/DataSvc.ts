'use strict';
import * as wjcCore from 'wijmo/wijmo';
import * as wjcOlap from 'wijmo/wijmo.olap';
import * as wjcOData from 'wijmo/wijmo.odata';
import { Injectable } from '@angular/core';

// Common data service
@Injectable()
export class DataSvc {

    initDataSets(): any[] {
        var url = 'https://demos.componentone.com/ASPNET/c1webapi/4.0.20172.105/api/dataengine/';
        return [
            // server (via WebAPI data engine services)
            { name: 'Data Engine (100k items)', value: url + 'complex10', server: true },
            { name: 'Data Engine (500k items)', value: url + 'complex50', server: true },
            { name: 'Data Engine (1m items)', value: url + 'complex100', server: true },
            { name: 'Data Source (100k items)', value: url + 'dataset10', server: true },
            { name: 'Data Source (500k items)', value: url + 'dataset50', server: true },
            { name: 'Data Source (1m items)', value: url + 'dataset100', server: true },
            { name: 'SSAS (Adventure Works Cube)', value: url + 'cube', server: true },

            // server (direct SSAS OLAP connection)
            {
                name: 'SSAS (Adventure Works Cube/direct)',
                value: {
                    url: 'https://ssrs.componentone.com/OLAP/msmdpump.dll',
                    cube: 'Adventure Works'
                },
                server: true
            },

            // client (local data)
            { name: 'Client (100 items)', value: this.getDataSet(100), server: false },
            { name: 'Client (50k items)', value: this.getDataSet(50000), server: false },
            { name: 'Client (100k items)', value: this.getDataSet(100000), server: false },
            { name: 'Client (500k items)', value: this.getDataSet(500000), server: false },
        ];
    }

    initShowTotals(): any {
        return [
            { name: 'None', value: wjcOlap.ShowTotals.None },
            { name: 'Grand totals', value: wjcOlap.ShowTotals.GrandTotals },
            { name: 'Subtotals', value: wjcOlap.ShowTotals.Subtotals }
        ];
    }

    initChartTypes(): any[] {
        return [
            { name: 'Column', value: wjcOlap.PivotChartType.Column },
            { name: 'Bar', value: wjcOlap.PivotChartType.Bar },
            { name: 'Scatter', value: wjcOlap.PivotChartType.Scatter },
            { name: 'Line', value: wjcOlap.PivotChartType.Line },
            { name: 'Area', value: wjcOlap.PivotChartType.Area },
            { name: 'Pie', value: wjcOlap.PivotChartType.Pie }
        ];
    }

    initViewDefs(): any[] {
        return [
            {
                name: "Sales by Product",
                def: "{\"showZeros\":false,\"showColumnTotals\":2,\"showRowTotals\":2,\"defaultFilterType\":1,\"fields\":[{\"binding\":\"Id\",\"header\":\"Id\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Product\",\"header\":\"Product\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Country\",\"header\":\"Country\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Date\",\"header\":\"Date\",\"dataType\":4,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"format\":\"d\",\"isContentHtml\":false},{\"binding\":\"Sales\",\"header\":\"Sales\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Downloads\",\"header\":\"Downloads\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Active\",\"header\":\"Active\",\"dataType\":3,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Discount\",\"header\":\"Discount\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false}],\"rowFields\":{\"items\":[\"Product\"]},\"columnFields\":{\"items\":[]},\"filterFields\":{\"items\":[]},\"valueFields\":{\"items\":[\"Sales\"]}}"
            },
            {
                name: "Sales by Country",
                def: "{\"showZeros\":false,\"showColumnTotals\":2,\"showRowTotals\":2,\"defaultFilterType\":1,\"fields\":[{\"binding\":\"Id\",\"header\":\"Id\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Product\",\"header\":\"Product\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Country\",\"header\":\"Country\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Date\",\"header\":\"Date\",\"dataType\":4,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"format\":\"d\",\"isContentHtml\":false},{\"binding\":\"Sales\",\"header\":\"Sales\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Downloads\",\"header\":\"Downloads\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Active\",\"header\":\"Active\",\"dataType\":3,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Discount\",\"header\":\"Discount\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false}],\"rowFields\":{\"items\":[\"Country\"]},\"columnFields\":{\"items\":[]},\"filterFields\":{\"items\":[]},\"valueFields\":{\"items\":[\"Sales\"]}}"
            },
            {
                name: "Sales and Downloads by Country",
                def: "{\"showZeros\":false,\"showColumnTotals\":2,\"showRowTotals\":2,\"defaultFilterType\":1,\"fields\":[{\"binding\":\"Id\",\"header\":\"Id\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Product\",\"header\":\"Product\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Country\",\"header\":\"Country\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Date\",\"header\":\"Date\",\"dataType\":4,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"format\":\"d\",\"isContentHtml\":false},{\"binding\":\"Sales\",\"header\":\"Sales\",\"dataType\":2,\"aggregate\":3,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Downloads\",\"header\":\"Downloads\",\"dataType\":2,\"aggregate\":3,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Active\",\"header\":\"Active\",\"dataType\":3,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Discount\",\"header\":\"Discount\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false}],\"rowFields\":{\"items\":[\"Country\"]},\"columnFields\":{\"items\":[]},\"filterFields\":{\"items\":[]},\"valueFields\":{\"items\":[\"Sales\",\"Downloads\"]}}"
            },
            {
                name: "Sales Trend by Product",
                def: "{\"showZeros\":false,\"showColumnTotals\":0,\"showRowTotals\":0,\"defaultFilterType\":1,\"fields\":[{\"binding\":\"Id\",\"header\":\"Id\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Product\",\"header\":\"Product\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Country\",\"header\":\"Country\",\"dataType\":1,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Date\",\"header\":\"Date\",\"dataType\":4,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"format\":\"MMM yyyy\",\"isContentHtml\":false},{\"binding\":\"Sales\",\"header\":\"Sales\",\"dataType\":2,\"aggregate\":3,\"showAs\":2,\"descending\":false,\"format\":\"p2\",\"isContentHtml\":false},{\"binding\":\"Downloads\",\"header\":\"Downloads\",\"dataType\":2,\"aggregate\":3,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false},{\"binding\":\"Active\",\"header\":\"Active\",\"dataType\":3,\"aggregate\":2,\"showAs\":0,\"descending\":false,\"isContentHtml\":false},{\"binding\":\"Discount\",\"header\":\"Discount\",\"dataType\":2,\"aggregate\":1,\"showAs\":0,\"descending\":false,\"format\":\"n0\",\"isContentHtml\":false}],\"rowFields\":{\"items\":[\"Date\"]},\"columnFields\":{\"items\":[\"Product\"]},\"filterFields\":{\"items\":[]},\"valueFields\":{\"items\":[\"Sales\"]}}"
            }
        ]

    }

    initCubeFields(): any[] {
        return [
            { header: 'Customer Location', dimensionType: 0, subFields: [
                { binding: '[Customer].[Country]', header: 'Country', dataType: 1, dimensionType: 6 },
                { binding: '[Customer].[State-Province]', header: 'State-Province', dataType: 1, dimensionType: 6 }
            ]},
            { header: 'Product Information', dimensionType: 0, subFields: [
                { binding: '[Product].[Product]', header: 'Product', dataType: 1, dimensionType: 6 },
                { binding: '[Product].[Model Name]', header: 'Model', dataType: 1, dimensionType: 6 },
                { binding: '[Product].[Style]', header: 'Style', dataType: 1, dimensionType: 6 },
                { binding: '[Product].[Category]', header: 'Category', dataType: 1, dimensionType: 6 },
                { binding: '[Product].[Product Line]', header: 'Line', dataType: 1, dimensionType: 6 }
            ]},
            { header: 'Internet Sales', dimensionType: 0, subFields: [
                { binding: '[Measures].[Internet Sales Amount]', header: 'Amount', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Order Quantity]', header: 'Order Quantity', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Extended Amount]', header: 'Extended Amount', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Freight Cost]', header: 'Freight Cost', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Total Product Cost]', header: 'Total Cost', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Gross Profit]', header: 'Gross Profit', dataType: 2, aggregate: 1, format: 'n0', dimensionType: 1 },
                { binding: '[Measures].[Internet Gross Profit Margin]', header: 'Gross Profit Margin', dataType: 2, aggregate: 1, format: 'p2', dimensionType: 1 }
            ]}
        ]
    }

    // gets a simple data set for basic demos
    getSimpleDataSet(cnt: number): wjcCore.CollectionView {
        var dtOct = new Date(2015, 9, 1),
            dtDec = new Date(2015, 11, 1),
            data = [
                { product: 'Wijmo', country: 'USA', sales: 10, downloads: 100, date: dtOct, active: true },
                { product: 'Wijmo', country: 'Japan', sales: 10, downloads: 100, date: dtOct, active: false },
                { product: 'Aoba', country: 'USA', sales: 10, downloads: 100, date: dtDec, active: true },
                { product: 'Aoba', country: 'Japan', sales: 10, downloads: 100, date: dtDec, active: false }
            ];
        for (var i = 0; i < cnt - 4; i++) {
            data.push({
                product: this.randomInt(1) ? 'Wijmo' : 'Aoba',
                country: this.randomInt(1) ? 'USA' : 'Japan',
                active: i % 2 == 0,
                date: new Date(2015 + this.randomInt(2), this.randomInt(11), this.randomInt(27) + 1),
                sales: 10 + this.randomInt(10),
                downloads: 10 + this.randomInt(190)
            });
        }
        return new wjcCore.CollectionView(data);
    }
    // gets a slightly more complex data set for more advanced demos
    private getDataSet(cnt: number): wjcCore.CollectionView {
        var countries = 'US,Germany,UK,Japan,Italy,Greece,Spain,Portugal'.split(','),
            products = 'Wijmo,Aoba,Xuni,Olap'.split(','),
            data = [];
        for (var i = 0; i < cnt; i++) {
            data.push({
                id: i,
                product: products[this.randomInt(products.length - 1)],
                country: countries[this.randomInt(countries.length - 1)],
                date: new Date(2015 + this.randomInt(2), this.randomInt(11), this.randomInt(27) + 1),
                sales: this.randomInt(10000),
                downloads: this.randomInt(10000),
                active: this.randomInt(1) ? true : false,
                discount: Math.random()
            });
        }
        return new wjcCore.CollectionView(data);
    }

    // gets a random integer between zero and max
    private randomInt(max: number): number {
        return Math.floor(Math.random() * (max + 1));
    }


}