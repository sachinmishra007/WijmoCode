import * as wjcCore from 'wijmo/wijmo';
import * as wjcInput from 'wijmo/wijmo.input';
import * as wjcGrid from 'wijmo/wijmo.grid';
import * as wjcOlap from 'wijmo/wijmo.olap';
import * as wjcOData from 'wijmo/wijmo.odata';
import * as wjcGridXlsx from 'wijmo/wijmo.grid.xlsx';
import * as wjcXlsx from 'wijmo/wijmo.xlsx';

// Angular
import { Component, EventEmitter, Input, Inject, enableProdMode, ViewChild, NgModule, AfterViewInit, ElementRef, Renderer2, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BrowserModule } from '@angular/platform-browser';
import { WjOlapModule, WjPivotPanel, WjPivotGrid } from 'wijmo/wijmo.angular2.olap';
import { WjGridModule, WjFlexGrid } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';

import { WjNavModule } from 'wijmo/wijmo.angular2.nav';
import { DataSvc } from './services/DataSvc';
import * as wjcPanel from 'wijmo/wijmo.angular2.olap';
import { map, each } from 'lodash';
import { Subject, Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as $ from 'jquery';

declare var require: any
declare var wijmo: any;
var { data1, data2, data3 } = require('./mock.js');


@Component({
  selector: 'app-cmp',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})



export class AppComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() id;
  old_sendHttpRequest = wijmo.olap._ServerConnection.prototype._sendHttpRequest;
  pivotGrid;
  ng;
  control;
  gridConfig;
  ShowSubtotal = true;
  showPagination = {
    isPaginationSet: false,
    currentPage: 1,
    totalItems: 0,
    endPage: 0,
    totalCount: 0,
    pageIndex: 1,
  }
  pagination = [];
  old_success = [];
  sub$ = new Subject<any>();
  manageSub$ = new Subscription();
  url = "http://localhost:63646/api/mydataengine/analyses";
  paginationUrl = "http://localhost:63646/api/mydataengine/GetPageData";
  constructor(
    private element: ElementRef,
    private http: HttpClient,
    private _renderer: Renderer2) {


  }

  ngOnInit() {
    // console.log(this.id);
  }

  ngOnDestroy() {
    this.manageSub$.unsubscribe();
  }

  previousClick() {
    this.showPagination.currentPage -= 1;
    data1.isGrandTotalRequired = this.ShowSubtotal;
    data1.pageIndex = this.showPagination.currentPage;
    data1.isSubTotalRequired = this.ShowSubtotal;
    this.ng.customData = JSON.stringify(data1);
    this.ng.refresh();
  }
  nextClick() {
    this.showPagination.currentPage += 1;
    data1.isGrandTotalRequired = this.ShowSubtotal;
    data1.pageIndex = this.showPagination.currentPage;
    data1.isSubTotalRequired = this.ShowSubtotal;
    this.ng.customData = JSON.stringify(data1);
    this.ng.refresh();
  }

  renderPagination() {
    this.manageSub$.add(
      this.sub$.subscribe((response) => {
        console.log(response);
        this.http.post(`${this.paginationUrl}`, {
          requestKey: response.id == 1 ? "8c3e8270-1528-47bd-85ac-663191c367631466240040000001146624" :
            response.id == 2 ? "f732e4fd-6607-424c-b1ad-876bb3d5a64d1466240040000001146624" : "48d2942a-01de-44e2-b695-12d1344c37391466240040000001146624"
        }).subscribe((response: any) => {
          this.showPagination.totalItems = response.totalRowCount;
          this.showPagination.totalCount = Math.ceil((this.showPagination.totalItems - 1) / (response.pageSize - 1))
          this.pagination.push({ ...this.showPagination });
          this.collapseEvent(this.level);
        });
      })
    );
  }

  showSubtotalValue() {
    this.createCollapsable();
    this.pivotGrid.collapsibleSubtotals = !this.ShowSubtotal;
    data1.isGrandTotalRequired = !this.ShowSubtotal;
    data1.isSubTotalRequired = !this.ShowSubtotal;
    this.showPagination.isPaginationSet = false;
    this.ng.customData = JSON.stringify(data1);
    this.ng.refresh();
  }
  itemFormatter(e) {

  }

  ngAfterViewInit() {
    let that = this;
    this.renderGrid(this.id);
    this.loadFields();
    this.renderPagination();
    this.pivotGrid = new wijmo.olap.PivotGrid(document.getElementById('wijmo' + this.id), {
      itemsSource: this.ng,
      showDetailOnDoubleClick: false,
      allowSorting: true,
      selectionMode: 1,
      autoScroll: false,
      // initialize: this.initGrid.bind(this),   
      customContextMenu: false,
      autoSizeMode: "None",
      collapsibleSubtotals: this.ShowSubtotal,
      itemFormatter: this.itemFormatter.bind(this)
    });

    this.pivotGrid.resizedRow.addHandler(function (s, e) {
      // console.log(`resizedRow`)
    });
    this.pivotGrid.resizingColumn.addHandler(function (s, e) {
      // that.collapseEvent(that.level);
      // console.log(`resizingColumn`)
    });
    this.pivotGrid.rowEditStarted.addHandler(function (s, e) {
      // console.log(`rowEditStarted`)
    });
    this.pivotGrid.rowEditStarting.addHandler(function (s, e) {
      // console.log(`rowEditStarted`)
    });
    this.pivotGrid.scrollPositionChanged.addHandler(function (s, e) {
      // console.log(`scrollPositionChanged`)
    });
    this.pivotGrid.selectionChanged.addHandler(function (s, e) {
      console.log(`selectionChanged`, s, e)
    });
    this.pivotGrid.selectionChanging.addHandler(function (s, e) {
      // console.log(`selectionChanging`,s,e);
    });

    this.pivotGrid.updatedLayout.addHandler(function (s, e) {
      // console.log(`updatedLayout`)
    });
    this.pivotGrid.updatedView.addHandler(function (s, e) {
      // console.log(`updatedView`)
    });
    this.pivotGrid.updatingLayout.addHandler(function (s, e) {
      // console.log(`updatingLayout`)
    });
    this.pivotGrid.updatingView.addHandler(function (s, e) {
      // console.log(`updatingView`)
    });
    this.pivotGrid.sortingColumn.addHandler(function (s, e) {
      console.log(`Component Id: ${that.id} sortingColumn`, s, e)
    });
    this.pivotGrid.sortedColumn.addHandler(function (s, e) {
      // console.log(`sortedColumn`,s,e)
    });
    // this.pivotGrid.formatItem.addHandler(function (s, e) {
    //   console.log(`formatItem`, s, e)
    // });


    // this.pivotGrid.initialized = this.initGrid.bind(this)
  }

  initGrid(s, e) {

  }

  loadFields() {

    let that = this;
    wijmo.olap.PivotField.prototype._getValue = function (item, formatted) {
      var value;
      if (this._ng && this._ng._server) {
        value = item[this.key];
      } else {
        value = this._binding._key
          ? item[this._binding._key]
          : this._binding.getValue(item);
      }


      var months = /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i;
      if (isNaN(value) && !isNaN(Date.parse(value)) && months.test(value) == false) {
        var datetype = true;
      }

      if (this._format == 'd') {
        return !formatted || typeof (value) == 'string'
          ? new Date(value)
          : wijmo.Globalize.format(value, this._format);

      }
      else {
        return !formatted || typeof (value) == 'string' || typeof (value) == 'number'
          ? value
          : wijmo.Globalize.format(value, this._format);
      }
    };

    Object.defineProperty(wijmo.olap.PivotEngine.prototype, 'isViewDefined', {
      get: function () {
        var vf = this.valueFields.length,
          rf = this.rowFields.length,
          cf = this.columnFields.length;
        return vf > 0 || rf > 0 || cf > 0;
      },
      enumerable: true,
      configurable: true
    });

    wijmo.olap._ServerConnection.prototype.getOutputView = function (callBack) {
      this.clearPendingRequests();
      this._getMyResults(callBack);
    };

    wijmo.olap._ServerConnection.prototype._getMyResults = function (callBack) {
      this._getResults(callBack);
    };


    // This method is used  to get the url for different commands.
    var old_getUrl = wijmo.olap._ServerConnection.prototype._getUrl;
    wijmo.olap._ServerConnection.prototype._getUrl = function (command, token, fieldName) {
      var url = old_getUrl.call(this, command, token, fieldName);
      if (command.toLowerCase() != 'result') {
        return url;
      }
      return that.url;
    }

    let olapData
    var customDefer
    wijmo.olap._ServerConnection.prototype._sendHttpRequest = function (cmd, settings) {
      switch (cmd) {
        case 'Analyses': // AnalysisData
        case 'Status':   // GetAnalysisStatus
          // remove the codes for these services as they are replaced with GetAnalysisResult.
          return;
        case 'Result':
          if (!settings) {
            settings = {};
          }

          // change the request type to POST
          settings.method = 'POST';

          // pass the view definition to the server.
          settings.data = {
          };
          // pass custom data to the server.
          settings.data.customData = {
            test1: this._ng.customData
          }
          customDefer = this._ng.customDefer;
          var id = this._ng.id;
          that.old_success[id] = settings.success;
          settings.success = function (resp) {
            that.sub$.next({
              response: JSON.parse(resp.responseText),
              id: id,
              statusCode: 1
            });
            that.old_success[id](resp);

          }
          settings.error = function (resp) {
            console.log('error');
          }
          that.old_sendHttpRequest.call(this, cmd, settings);
      }
    }
  }

  renderGrid(id) {
    let RO = ["Item", "Category", "Sub-Category", "Region", "Year", "Quarter", "Month", "Total"];
    this.ng = new wijmo.olap.PivotEngine();
    this.ng.id = id;
    this.ng.autoGenerateFields = false;
    this.ng.sortOnServer = true;
    this.ng.allowSorting = false;
    this.ng.showZeros = false;
    this.ng.showColumnTotals = wijmo.olap.ShowTotals.GrandTotals;
    this.ng.showRowTotals = wijmo.olap.ShowTotals.Subtotals;
    this.ng.totalsBeforeData = false;
    this.ng.itemsSource = this.url;
    this.ng.customData = id == 1 ? JSON.stringify(data1) : id == 2 ? JSON.stringify(data2) : JSON.stringify(data3);

    this.ng.fields.splice(0, this.ng.fields.length);
    this.ng.rowFields.splice(0, this.ng.rowFields.length);
    this.ng.columnFields.splice(0, this.ng.columnFields.length);
    this.ng.valueFields.splice(0, this.ng.valueFields.length);


    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Category', 'Category', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Item', 'Item', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Month', 'Month', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Quarter', 'Quarter', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Region', 'Region', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Sub-Category', 'Sub-Category', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Total', 'Total', { width: 85 }));
    // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Year', 'Year', { width: 85 }));
    // // this.ng.fields.push(new wijmo.olap.PivotField(this.ng, 'Spend (DKK)', 'Spend (DKK)', { width: 85 }));

    // this.ng.rowFields.push(new wijmo.olap.PivotField(this.ng, 'Category', 'Category', { width: 85 }));
    // this.ng.rowFields.push(new wijmo.olap.PivotField(this.ng, 'Item', 'Item', { width: 85 }));
    // this.ng.rowFields.push(new wijmo.olap.PivotField(this.ng, 'Month', 'Level 3 Category', { width: 85 }));
    // this.ng.rowFields.push(new wijmo.olap.PivotField(this.ng, 'Level 4 Category', 'Level 4 Category', { width: 85 }));
    // this.ng.rowFields.push(new wijmo.olap.PivotField(this.ng, 'Level 5 Category', 'Level 5 Category', { width: 85 }));

    // this.ng.columnFields.push(new wijmo.olap.PivotField(this.ng, 'Supplier Region', 'Supplier Region', { width: 120 }));
    // this.ng.columnFields.push(new wijmo.olap.PivotField(this.ng, 'Supplier City', 'Supplier City', { width: 120 }));

    // this.ng.valueFields.push(new wijmo.olap.PivotField(this.ng, 'Spend in USD', 'Spend in USD', { width: 120 }));
    // this.ng.valueFields.push(new wijmo.olap.PivotField(this.ng, 'Spend (DKK)', 'Spend (DKK)', { width: 85 }));
    for (var i = 0; i < RO.length; i++) {
      this.ng.fields.push(new wijmo.olap.PivotField(this.ng, RO[i], RO[i]));
    }

    this.ng.rowFields.push(RO[0], RO[1], RO[2], RO[3], RO[4], RO[5], RO[6]);
    //ng.columnFields.push($scope.RO[2]);
    this.ng.valueFields.push(RO[7]);
    this.ng.valueFields[0].format = "C$"; 
    // this.pivotGrid.refreshCells();
    this.createCollapsable();
  }
  level = 0;
  createCollapsable() {
    let that = this;
    var divElement = document.getElementById('wijmoButton' + this.id);
    divElement.classList.add('wijmo-button-cont');
    divElement.innerHTML = '';
    that.level = 1;
    if (this.ng.rowFields && this.ng.rowFields.length > 1) {
      for (var i = 0; i < this.ng.rowFields.length; i++) {
        var btn = document.createElement('button');
        btn.classList.add('wijmo-button');
        btn.classList.add('wijmo-button' + this.id);
        btn.textContent = (i + 1).toString();
        btn.setAttribute('data-level', (i + 1).toString());
        divElement.appendChild(btn);
      }
      // this._renderer.addClass(document.getElementsByName('.wj-flexgrid'), 'active-wj-buttons');
    }
    else {
      // this._renderer.removeClass(document.getElementsByName('.wj-flexgrid'), 'active-wj-buttons');

      // this._renderer.removeClass('wj-flexgrid', 'active-wj-buttons');
      // $('.wj-flexgrid').removeClass('active-wj-buttons');
    }
    divElement.addEventListener('mousedown', function (e) {
      var btn = document.elementFromPoint(e.clientX, e.clientY), level = btn ? btn.getAttribute('data-level') : null;
      if (level) {
        e.preventDefault();
        that.level = parseInt(level)
        that.collapseEvent(that.level);

      }
    });

  }
  withoutFixed = true;
  collapseEvent(level) {

    $('.wijmo-button' + this.id).removeClass('selected');
    $('.wijmo-button' + this.id).eq(this.level - 1).addClass('selected');
    this.pivotGrid.collapseRowsToLevel(level);

  }

}