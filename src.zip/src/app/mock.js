const data1 = {};
const data = {};
const data2 = {};
const data3 = {};
const data4 = {};
module.exports = { data1, data, data2, data3, data4 };
