import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';
import { WjOlapModule } from 'wijmo/wijmo.angular2.olap';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { FormsModule } from '@angular/forms';
import { WjNavModule } from 'wijmo/wijmo.angular2.nav';
import { DataSvc } from './services/DataSvc';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TempComponent } from './temp/temp.component';

@NgModule({
  declarations: [
    AppComponent,
    TempComponent
  ],
  imports: [
    HttpClientModule,
    WjInputModule, WjOlapModule, WjGridModule, WjGridFilterModule, BrowserModule, FormsModule, WjNavModule
  ],
  providers: [DataSvc],
  bootstrap: [TempComponent]
})
export class AppModule { }
